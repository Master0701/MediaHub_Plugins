"""MediaHub Offline LLM worker, phase 1: attach to an explicitly configured local llama-server."""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any


class OfflineLLMError(RuntimeError):
    pass


def _endpoint() -> str:
    import ipaddress
    from urllib.parse import urlsplit

    value = os.environ.get(
        "MEDIAHUB_LLAMA_SERVER_URL",
        "http://127.0.0.1:8767",
    ).rstrip("/")

    try:
        parsed = urlsplit(value)
        hostname = parsed.hostname
        port = parsed.port
    except ValueError as exc:
        raise OfflineLLMError("Ungueltige KI-Server-Adresse") from exc

    if (
        parsed.scheme != "http"
        or not hostname
        or not port
        or parsed.username
        or parsed.password
        or parsed.path
        or parsed.query
        or parsed.fragment
    ):
        raise OfflineLLMError("Ungueltige lokale KI-Server-Adresse")

    try:
        address = ipaddress.ip_address(hostname)
    except ValueError:
        allowed = (
            hostname.lower() == "localhost"
            or hostname.lower().endswith(".local")
            or hostname.lower().endswith(".lan")
            or (
                "." not in hostname
                and hostname.replace("-", "").isalnum()
            )
        )
    else:
        allowed = address.is_private or address.is_loopback

    if not allowed:
        raise OfflineLLMError(
            "Nur lokale oder private Heimnetz-Adressen erlaubt"
        )

    return value


def _messages(payload: dict[str, Any]) -> list[dict[str, str]]:
    messages = payload.get("messages")
    if messages is None:
        prompt = payload.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("payload.prompt oder payload.messages erforderlich")
        messages = [{"role": "user", "content": prompt}]
    if not isinstance(messages, list) or not messages or len(messages) > 40:
        raise ValueError("payload.messages muss 1 bis 40 Nachrichten enthalten")
    result = []
    for item in messages:
        if not isinstance(item, dict) or item.get("role") not in {"system", "user", "assistant"}:
            raise ValueError("Ungueltige Nachrichtenrolle")
        content = item.get("content")
        if not isinstance(content, str) or not content.strip() or len(content) > 50000:
            raise ValueError("Nachrichteninhalt ungueltig oder zu lang")
        result.append({"role": item["role"], "content": content})
    return result


def create_handler(context: dict[str, Any]):
    def handler(request: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(request, dict):
            raise ValueError("Job muss ein Objekt sein")
        payload = request.get("payload") or {}
        if not isinstance(payload, dict):
            raise ValueError("payload muss ein Objekt sein")
        messages = _messages(payload)

        if not any(item["role"] == "system" for item in messages):
            messages.insert(0, {
                "role": "system",
                "content": (
                    "Du bist der lokale MediaHub-KI-Assistent. "
                    "Antworte standardmaessig auf Deutsch, "
                    "freundlich, klar und direkt. "
                    "MediaHub ist ein selbst entwickeltes "
                    "Medienverwaltungsprogramm. "
                    "Erfinde keine Informationen. "
                    "Wenn du etwas nicht weisst, sage es."
                ),
            })

        thinking = payload.get("thinking", False)
        if not isinstance(thinking, bool):
            raise ValueError("payload.thinking muss boolesch sein")

        if not thinking:
            for item in reversed(messages):
                if item["role"] == "user":
                    if "/no_think" not in item["content"]:
                        item["content"] += "\n/no_think"
                    break
        max_tokens = int(payload.get("max_tokens", 256))
        if not 1 <= max_tokens <= 2048:
            raise ValueError("max_tokens muss zwischen 1 und 2048 liegen")
        temperature = float(payload.get("temperature", 0.7))
        if not 0 <= temperature <= 2:
            raise ValueError("temperature muss zwischen 0 und 2 liegen")
        data = json.dumps({"messages": messages, "max_tokens": max_tokens, "temperature": temperature, "stream": False, "chat_template_kwargs": {"enable_thinking": thinking}}).encode("utf-8")
        req = urllib.request.Request(_endpoint() + "/v1/chat/completions", data=data, headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=120) as response:
                if response.status != 200:
                    raise OfflineLLMError(f"llama-server HTTP {response.status}")
                result = json.loads(response.read(4 * 1024 * 1024).decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise OfflineLLMError(f"Lokaler llama-server nicht erreichbar: {exc}") from exc
        try:
            answer = result["choices"][0]["message"]["content"]
            if not isinstance(answer, str):
                raise TypeError("Antwort kein Text")
            if not answer.strip():
                raise OfflineLLMError("llama-server lieferte keinen Antworttext; moeglicherweise wurde das Tokenlimit im Thinking-Modus verbraucht")
        except (KeyError, IndexError, TypeError) as exc:
            raise OfflineLLMError("Ungueltige llama-server-Antwort") from exc
        return {"status": "completed", "engine": "llama.cpp", "text": answer, "usage": result.get("usage", {}), "provider": "local_llama_server"}
    return handler


def register(context: dict[str, Any]) -> None:
    context["workers"].register(
        worker_id="mediahub.interaktions_ki.worker",
        name="MediaHub Interaktions-KI Worker",
        job_types=["chat", "text_generation"],
        handler=create_handler(context),
        metadata={"plugin_id": context["plugin_id"], "plugin_version": context["plugin_version"], "engine": "llama.cpp", "phase": "external_local_server", "installation_managed": False},
    )


class MediaHubInteraktionsKIPlugin:
    def register(self, context: dict[str, Any]) -> None:
        register(context)

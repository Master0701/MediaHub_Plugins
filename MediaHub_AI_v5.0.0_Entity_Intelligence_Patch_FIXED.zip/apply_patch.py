from __future__ import annotations

import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: erwartet 1 Treffer, gefunden {count}")
    return text.replace(old, new, 1)


def regex_once(text: str, pattern: str, replacement: str, label: str) -> str:
    new_text, count = re.subn(
        pattern,
        replacement,
        text,
        count=1,
        flags=re.MULTILINE,
    )
    if count != 1:
        raise RuntimeError(f"{label}: erwartet 1 Treffer, gefunden {count}")
    return new_text


def main() -> int:
    repo = Path(sys.argv[1]).resolve()
    plugin_dir = repo / "plugins" / "ai_assistant"
    manifest_path = plugin_dir / "plugin.json"
    plugin_path = plugin_dir / "plugin.py"
    validation_test = (
        plugin_dir
        / "tests"
        / "test_complete_graph_validation_groups_v433.py"
    )

    if not manifest_path.is_file() or not plugin_path.is_file():
        raise RuntimeError("MediaHub-KI-Assistent wurde nicht gefunden.")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    current = str(manifest.get("version") or "")
    if current != "4.9.0":
        raise RuntimeError(
            f"Dieser Patch erwartet v4.9.0, gefunden wurde {current!r}."
        )

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = repo / f"_patch_backup_ai_v500_{stamp}"
    backup.mkdir(parents=True)

    for source in (manifest_path, plugin_path, validation_test):
        if source.exists():
            target = backup / source.relative_to(repo)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)

    files_root = Path(__file__).resolve().parent / "files"
    for source in files_root.rglob("*"):
        if source.is_file():
            target = repo / source.relative_to(files_root)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)

    manifest["version"] = "5.0.0"
    capabilities = list(manifest.get("capabilities") or [])
    for capability in (
        "entity_intelligence",
        "organization_entity_detection",
        "location_entity_detection",
        "planet_entity_detection",
        "spacecraft_entity_detection",
        "vehicle_entity_detection",
        "species_entity_detection",
        "technology_entity_detection",
        "weapon_entity_detection",
        "artifact_entity_detection",
        "entity_relationship_detection",
    ):
        if capability not in capabilities:
            capabilities.append(capability)
    manifest["capabilities"] = sorted(capabilities)
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    text = plugin_path.read_text(encoding="utf-8")

    text = replace_once(
        text,
        "from services.character_relationship_intelligence import "
        "CharacterRelationshipIntelligence\n",
        "from services.character_relationship_intelligence import "
        "CharacterRelationshipIntelligence\n"
        "from services.entity_intelligence import EntityIntelligence\n",
        "Import",
    )

    text = regex_once(
        text,
        r'^(\s*VERSION\s*=\s*)"[^"]+"',
        r'\1"5.0.0"',
        "VERSION",
    )

    text = replace_once(
        text,
        "        self.character_relationship_intelligence = "
        "CharacterRelationshipIntelligence()\n",
        "        self.character_relationship_intelligence = "
        "CharacterRelationshipIntelligence()\n"
        "        self.entity_intelligence = EntityIntelligence()\n",
        "Initialisierung",
    )

    # Insert directly after the completed v4.9.0 analyze() call.
    analyze_anchor = (
        "        character_relationship_intelligence = "
        "self.character_relationship_intelligence.analyze(\n"
        "            main_node=main_graph_node,\n"
        '            text=str(scan.get("text_preview") or ""),\n'
        "            source=dict(source),\n"
        "            character_roles=character_role_intelligence,\n"
        "        )\n"
    )
    analyze_insert = (
        analyze_anchor
        + "        entity_intelligence = self.entity_intelligence.analyze(\n"
        + "            main_node=main_graph_node,\n"
        + '            text=str(scan.get("text_preview") or ""),\n'
        + "            source=dict(source),\n"
        + "            character_roles=character_role_intelligence,\n"
        + "        )\n"
    )
    text = replace_once(
        text,
        analyze_anchor,
        analyze_insert,
        "Analyseaufruf",
    )

    text = replace_once(
        text,
        "                character_relationship_intelligence,\n",
        "                character_relationship_intelligence,\n"
        "                entity_intelligence,\n",
        "Validatorgruppe",
    )

    # Insert entity node/edge merge immediately before knowledge graph build.
    merge_anchor = (
        "        knowledge_graph = self.knowledge_graph_builder.build(\n"
    )
    merge_block = (
        '        for item in entity_intelligence.get("nodes") or []:\n'
        '            if item.get("key") not in node_keys:\n'
        '                graph_proposal.setdefault("nodes", []).append(item)\n'
        '                node_keys.add(item.get("key"))\n'
        '\n'
        '        for item in entity_intelligence.get("edges") or []:\n'
        '            key = (\n'
        '                item.get("edge_type"),\n'
        '                item.get("source_node_key"),\n'
        '                item.get("target_node_key"),\n'
        '            )\n'
        '            if key not in edge_keys:\n'
        '                graph_proposal.setdefault("edges", []).append(item)\n'
        '                edge_keys.add(key)\n'
        '\n'
        + merge_anchor
    )
    text = replace_once(
        text,
        merge_anchor,
        merge_block,
        "Graph-Proposal-Merge",
    )

    text = replace_once(
        text,
        '                list(character_relationship_intelligence.get("nodes") or []),\n',
        '                list(character_relationship_intelligence.get("nodes") or []),\n'
        '                list(entity_intelligence.get("nodes") or []),\n',
        "Knowledge-Graph-Nodes",
    )

    text = replace_once(
        text,
        '                list(character_relationship_intelligence.get("edges") or []),\n',
        '                list(character_relationship_intelligence.get("edges") or []),\n'
        '                list(entity_intelligence.get("edges") or []),\n',
        "Knowledge-Graph-Edges",
    )

    text = replace_once(
        text,
        '        context.document["character_relationship_intelligence"] = '
        'character_relationship_intelligence\n',
        '        context.document["character_relationship_intelligence"] = '
        'character_relationship_intelligence\n'
        '        context.document["entity_intelligence"] = entity_intelligence\n',
        "Reasoning Context",
    )

    payload_old = (
        '            "character_relationship_intelligence": '
        'character_relationship_intelligence,\n'
        '            "graph_validation": graph_validation,'
    )
    payload_new = (
        '            "character_relationship_intelligence": '
        'character_relationship_intelligence,\n'
        '            "entity_intelligence": entity_intelligence,\n'
        '            "graph_validation": graph_validation,'
    )
    payload_count = text.count(payload_old)
    if payload_count < 2:
        raise RuntimeError(
            f"Payloads: erwartet mindestens 2 Treffer, gefunden {payload_count}"
        )
    text = text.replace(payload_old, payload_new)

    plugin_path.write_text(text, encoding="utf-8")

    test_text = validation_test.read_text(encoding="utf-8")
    test_text = replace_once(
        test_text,
        '    "character_relationship_intelligence",\n',
        '    "character_relationship_intelligence",\n'
        '    "entity_intelligence",\n',
        "Validator-Test",
    )
    validation_test.write_text(test_text, encoding="utf-8")

    print("MediaHub KI-Assistent wurde erfolgreich auf v5.0.0 aktualisiert.")
    print(f"Sicherung: {backup}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

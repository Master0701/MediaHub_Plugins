# MediaHub KI-Assistent v5.0.0 – Entity Intelligence

Korrigierter Patch für den tatsächlichen v4.9.0-Codeaufbau.

Neu:

- Organisationen, Orte, Planeten, Raumschiffe, Fahrzeuge
- Spezies, Technologien, Waffen und Artefakte
- explizite Entitätsbeziehungen
- Integration in Validator, Graph Proposal, Knowledge Graph,
  Reasoning Context und Scan-Ausgabe
- automatische Übernahme bleibt deaktiviert

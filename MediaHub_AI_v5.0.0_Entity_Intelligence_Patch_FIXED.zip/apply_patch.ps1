param(
    [Parameter(Mandatory = $true)]
    [string]$RepositoryRoot
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$patcher = Join-Path $root "apply_patch.py"

& python $patcher $RepositoryRoot
if ($LASTEXITCODE -ne 0) {
    throw "v5.0.0-Patch wurde mit Fehlercode $LASTEXITCODE beendet."
}
